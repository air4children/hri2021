
# arXiv submission

0. cp -r tex/ arxiv/
1. cp image files to arxiv path
2. Copy references.bib in the path 
cp ../references/references.bib .

4. compite in one path
uncomment
```
\bibliography{references}
```
compile tex file
```
pdflatex main.tex
bibtex main
```

uncomment/comment

```
%\bibliography{../references/references}
\input{main.bbl}
```

compile tex
```
pdflatex main-arxiv.tex
pdflatex main-arxiv.tex
```


clean project 
```
rm -f *.aux *.blg *.log *.out main.pdf comment.cut
```

4. compress it as zip and upload it
```
zip -r arxiv-v00.zip ../arxiv/
```

